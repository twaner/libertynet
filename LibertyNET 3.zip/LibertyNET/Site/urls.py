from django.conf.urls import patterns, url
from Site.views import addclientsite

urlpatterns = patterns('',

                      )
