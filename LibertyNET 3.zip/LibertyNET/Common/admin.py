from django.contrib import admin
from Common.models import Genre, UserProfile

admin.site.register(Genre)
admin.site.register(UserProfile)
# Register your models here.
