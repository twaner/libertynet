from django.contrib import admin
from Employee.models import Title

admin.site.register(Title)

# Register your models here.
