$worker = $("#selector fixedWidth hover :span");
$state_worker = document.getElementById("id_state");
$worker.innerHTML = $state_worker.state_worker.selectedIndex;
