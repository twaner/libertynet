"""from django.test import TestCase
from Work.factories import JobFactory, TaskFactory, TicketFactory, WageFactory
"""
#region Work Factory
#endregion
