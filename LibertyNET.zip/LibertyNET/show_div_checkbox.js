
    function fnchecked(blnchecked){
        document.getElementById("address").style.display =
        (blnchecked) ? "" : "none";
    }
