from django.test import TestCase
#from Equipment.factories import